/* Single place to update business details, links, menu and gallery.
   Placeholders ending in _URL_HERE are detected by main.js and shown
   as "not set" instead of rendering a broken link. */
const CAFE = {
  name: "Ashvi Cafe Corner",
  nameHindi: "अश्वि कैफे कॉर्नर",
  phoneDisplay: "+91 70207 93497",
  phoneTel: "+917020793497",
  address: [
    "Vithalapur Wageri, Commerce Centre,",
    "Zariwada Vithallapur, Vithallapur,",
    "Sanquelim, Goa 403505, India",
  ],
  priceRange: "₹1–200 per person",
  rating: { value: "4.1", outOf: "5", count: 17 },
  womenOwned: true,

  // Owner must confirm before launch.
  hours: [
    { days: "Monday – Saturday", time: "10:00 AM – 10:00 PM" },
    { days: "Sunday", time: "9:00 AM – 5:00 PM" },
  ],
  hoursNeedConfirmation: true,

  links: {
    swiggy: "SWIGGY_URL_HERE",
    // Leave empty to use a Google Maps search built from the address.
    maps: "",
    googleReviews: "GOOGLE_REVIEWS_URL_HERE",
  },
  canonicalUrl: "https://CANONICAL_URL_HERE/",

  // Add `image: "images/file.jpg"` and `price: "₹120"` only when real.
  menu: [
    { category: "Burgers", items: [{ name: "KFC Burger" }] },
    { category: "Pizza", items: [{ name: "Loaded Pizza" }] },
    { category: "Momos", items: [{ name: "Momos" }] },
    { category: "Sandwiches", items: [{ name: "Mushroom Sandwich" }] },
    {
      category: "Chicken",
      items: [{ name: "Chicken Pooee" }, { name: "Chicken Drumsticks" }],
    },
    { category: "Beverages", items: [{ name: "Tea" }] },
  ],

  // Real photos only: { src, alt, width, height, category }.
  heroImage: null, // e.g. { src: "images/hero.jpg", alt: "...", width: 1600, height: 1000 }
  gallery: [],
};
