/* Fills the page from CAFE (config.js). Uses textContent only, never innerHTML. */
(function () {
  const isPlaceholder = (url) => !url || /_URL_HERE/.test(url);
  const el = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  };

  const addressText = CAFE.address.join(" ");
  const mapsDirections =
    CAFE.links.maps ||
    "https://www.google.com/maps/dir/?api=1&destination=" +
      encodeURIComponent(CAFE.name + ", " + addressText);

  const linkTargets = {
    swiggy: CAFE.links.swiggy,
    reviews: CAFE.links.googleReviews,
    directions: mapsDirections,
    call: "tel:" + CAFE.phoneTel,
  };

  const textValues = {
    name: CAFE.name,
    nameHindi: CAFE.nameHindi,
    phoneDisplay: CAFE.phoneDisplay,
    priceRange: CAFE.priceRange,
    ratingText: CAFE.rating.value + " / " + CAFE.rating.outOf,
    ratingCount: "from " + CAFE.rating.count + " Google reviews",
  };

  document.querySelectorAll("[data-bind]").forEach((node) => {
    node.textContent = textValues[node.dataset.bind];
  });

  document.querySelectorAll("[data-link]").forEach((node) => {
    const url = linkTargets[node.dataset.link];
    if (isPlaceholder(url)) {
      node.classList.add("is-unset");
      node.setAttribute("aria-disabled", "true");
      node.removeAttribute("target");
    } else {
      node.href = url;
    }
  });

  document.querySelectorAll(".is-unset").forEach((node) => {
    node.addEventListener("click", (event) => event.preventDefault());
  });

  // Address and hours
  const address = document.getElementById("address");
  address.append(el("strong", "", CAFE.name));
  CAFE.address.forEach((line) => {
    address.append(document.createElement("br"), line);
  });

  const hours = document.getElementById("hours");
  CAFE.hours.forEach((row) => {
    hours.append(el("dt", "", row.days), el("dd", "", row.time));
  });
  if (CAFE.hoursNeedConfirmation) {
    document.getElementById("hours-note").textContent =
      "Listed hours are approximate. [OWNER TO CONFIRM before launch.]";
  }

  // Menu
  const menuList = document.getElementById("menu-list");
  if (!CAFE.menu.length) {
    menuList.append(el("p", "note", "The menu is being updated. Please check Swiggy."));
  }
  CAFE.menu.forEach((group) => {
    const section = el("section", "menu-group");
    section.append(el("h3", "", group.category));
    const list = el("ul", "menu-items");
    group.items.forEach((item) => {
      const row = el("li");
      row.append(el("span", "item-name", item.name));
      if (item.price) row.append(el("span", "item-price", item.price));
      if (item.description) row.append(el("p", "item-desc", item.description));
      list.append(row);
    });
    section.append(list);
    menuList.append(section);
  });

  // Hero and gallery images
  const heroMedia = document.getElementById("hero-media");
  const makeImage = (photo, eager) => {
    const img = el("img");
    img.src = photo.src;
    img.alt = photo.alt;
    img.width = photo.width;
    img.height = photo.height;
    if (!eager) img.loading = "lazy";
    img.decoding = "async";
    return img;
  };
  if (CAFE.heroImage) {
    heroMedia.append(makeImage(CAFE.heroImage, true));
  } else {
    heroMedia.classList.add("placeholder");
    heroMedia.append(el("p", "", "[OWNER TO PROVIDE: hero photo]"));
  }

  const galleryGrid = document.getElementById("gallery-grid");
  if (!CAFE.gallery.length) {
    galleryGrid.classList.add("placeholder");
    galleryGrid.append(el("p", "", "[OWNER TO PROVIDE: photos of food, drinks and the café]"));
  }
  CAFE.gallery.forEach((photo) => {
    const figure = el("figure");
    figure.append(makeImage(photo, false));
    galleryGrid.append(figure);
  });

  // Mobile navigation
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("nav");
  const setNav = (open) => {
    toggle.setAttribute("aria-expanded", String(open));
    nav.classList.toggle("open", open);
  };
  toggle.addEventListener("click", () => setNav(toggle.getAttribute("aria-expanded") !== "true"));
  nav.addEventListener("click", (event) => {
    if (event.target.tagName === "A") setNav(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") setNav(false);
  });

  document.getElementById("year").textContent = new Date().getFullYear();

  // Structured data: only verified fields (no hours, rating or coordinates).
  const schema = {
    "@context": "https://schema.org",
    "@type": "CafeOrCoffeeShop",
    name: CAFE.name,
    telephone: CAFE.phoneTel,
    priceRange: CAFE.priceRange,
    address: {
      "@type": "PostalAddress",
      streetAddress: "Vithalapur Wageri, Commerce Centre, Zariwada Vithallapur",
      addressLocality: "Sanquelim",
      addressRegion: "Goa",
      postalCode: "403505",
      addressCountry: "IN",
    },
  };
  if (!isPlaceholder(CAFE.links.swiggy)) schema.hasMenu = CAFE.links.swiggy;
  const script = document.createElement("script");
  script.type = "application/ld+json";
  script.textContent = JSON.stringify(schema);
  document.head.append(script);
})();
