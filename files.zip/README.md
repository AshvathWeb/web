# Ashvi Cafe Corner website

A static one-page site (HTML, CSS, vanilla JS). No build step, no dependencies, no backend.

## Files
- `config.js`: **all business details, links, menu and gallery live here.** Edit this first.
- `index.html`: page structure. `styles.css`: design tokens (top of file) and styles.
- `main.js`: fills the page from `config.js`. Uses `textContent` only (no HTML injection).
- `robots.txt`, `sitemap.xml`, `favicon.svg`.

## Run
Open `index.html` in a browser, or serve the folder with any static host (Netlify, Cloudflare Pages, GitHub Pages).

## Before launch (owner / client must provide)
1. `links.swiggy`: the real Swiggy outlet URL (button shows "link not set" until supplied).
2. `links.googleReviews`: real Google reviews URL. `links.maps`: optional; otherwise directions use a Google Maps search of the address.
3. Real photos: `heroImage` and `gallery` in `config.js`. Put files in an `images/` folder, give each real `width`/`height` and descriptive `alt`. Compress to WebP/JPEG first.
4. Menu prices/descriptions/images (omitted until real). Menu categories are grouped from the known item names; confirm the full menu.
5. Confirm opening hours, then set `hoursNeedConfirmation: false`.
6. Owner's story for the About text in `index.html` (marked `[OWNER TO PROVIDE]`), and any review excerpts with permission.
7. Replace `CANONICAL_URL_HERE` in `index.html`, `config.js`, `robots.txt`, `sitemap.xml`. Add an `og:image` once a photo exists.

## Not included (by design)
- No contact form, ordering, booking or payments. Ordering is on Swiggy. A contact form would need a backend or form service: validate and rate-limit server-side and keep keys on the server.
- No "Open now" badge (would need correct timezone/schedule logic).
- Structured data omits hours, rating and coordinates until verified.

## Known limitations
- Menu and contact details are rendered by JavaScript; without JS they will not appear.
- Not yet tested in real browsers/devices: please check 320px to 1440px+, keyboard navigation and contrast before launch.
